(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: Performance Comparison ---
  var chartPerf = echarts.init(document.getElementById('chart-performance'), null, { renderer: 'svg' });

  chartPerf.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: {
        type: 'shadow'
      },
      formatter: function(params) {
        var result = params[0].axisValue + '张表关联<br/>';
        params.forEach(function(item) {
          result += item.marker + item.seriesName + ': ' + item.value + ' ms<br/>';
        });
        return result;
      }
    },
    legend: {
      data: ['星型模式', '规范化模型'],
      textStyle: { color: muted, fontSize: 13 },
      top: 0
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: ['3 表', '4 表', '5 表', '6 表', '7 表', '8 表'],
      axisLabel: { color: muted, fontSize: 12 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false },
      name: '关联表数量',
      nameTextStyle: { color: muted, fontSize: 12 },
      nameGap: 12
    },
    yAxis: {
      type: 'value',
      name: '查询耗时 (ms)',
      nameTextStyle: { color: muted, fontSize: 12 },
      nameGap: 12,
      axisLabel: { color: muted, fontSize: 12 },
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [
      {
        name: '星型模式',
        type: 'bar',
        data: [45, 65, 90, 120, 155, 195],
        itemStyle: {
          color: accent,
          borderRadius: [4, 4, 0, 0]
        },
        barWidth: '30%'
      },
      {
        name: '规范化模型',
        type: 'bar',
        data: [50, 85, 130, 190, 270, 370],
        itemStyle: {
          color: accent2,
          borderRadius: [4, 4, 0, 0]
        },
        barWidth: '30%'
      }
    ]
  });

  window.addEventListener('resize', function() {
    chartPerf.resize();
  });
})();
