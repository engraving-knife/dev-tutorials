(function () {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart 1: 版本演进时间线 ---
  var chart1 = echarts.init(document.getElementById('chart-versions'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      formatter: function (params) {
        var p = params[0];
        return '<b>' + p.name + '</b><br/>发布时间：' + p.data[1] + ' 年';
      }
    },
    grid: { left: 60, right: 30, top: 30, bottom: 50 },
    xAxis: {
      type: 'category',
      data: ['0.7', '0.90', '1.0', '2.0', '5.0', '6.0', '7.0', '8.0'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '发布年份',
      nameTextStyle: { color: muted },
      min: 2009,
      max: 2023,
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted }
    },
    series: [{
      name: '发布时间',
      type: 'line',
      smooth: true,
      symbolSize: 12,
      data: [
        ['0.7', 2010],
        ['0.90', 2013],
        ['1.0', 2014],
        ['2.0', 2015],
        ['5.0', 2016],
        ['6.0', 2018],
        ['7.0', 2019],
        ['8.0', 2022]
      ],
      lineStyle: { width: 3, color: accent },
      itemStyle: { color: accent2, borderColor: '#ffffff', borderWidth: 2 },
      areaStyle: {
        color: {
          type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: accent + '55' },
            { offset: 1, color: accent + '05' }
          ]
        }
      }
    }]
  });
  window.addEventListener('resize', function () { chart1.resize(); });

  // --- Chart 2: 数据规模与查询延迟对比 (MySQL vs ES) ---
  var chart2 = echarts.init(document.getElementById('chart-compare'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: { type: 'shadow' },
      formatter: function (params) {
        var s = '<b>数据量 ' + params[0].name + '</b><br/>';
        params.forEach(function (p) {
          s += p.marker + p.seriesName + '：约 ' + p.value + ' ms<br/>';
        });
        return s;
      }
    },
    legend: {
      data: ['MySQL LIKE 模糊查询', 'Elasticsearch 全文检索'],
      textStyle: { color: muted },
      top: 0
    },
    grid: { left: 70, right: 30, top: 40, bottom: 40 },
    xAxis: {
      type: 'category',
      data: ['10 万条', '100 万条', '1000 万条'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '查询耗时 (ms)',
      nameTextStyle: { color: muted },
      type: 'log',
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted }
    },
    series: [
      {
        name: 'MySQL LIKE 模糊查询',
        type: 'bar',
        barWidth: 34,
        data: [120, 1800, 30000],
        itemStyle: { color: muted, borderRadius: [6, 6, 0, 0] }
      },
      {
        name: 'Elasticsearch 全文检索',
        type: 'bar',
        barWidth: 34,
        data: [18, 42, 96],
        itemStyle: { color: accent, borderRadius: [6, 6, 0, 0] }
      }
    ]
  });
  window.addEventListener('resize', function () { chart2.resize(); });

  // --- Chart 3: Elastic Stack 使用场景分布 ---
  var chart3 = echarts.init(document.getElementById('chart-scenes'), null, { renderer: 'svg' });
  chart3.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      formatter: '{b}：{c}%'
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      textStyle: { color: muted }
    },
    series: [{
      name: '典型应用场景',
      type: 'pie',
      radius: ['45%', '72%'],
      center: ['38%', '50%'],
      avoidLabelOverlap: true,
      itemStyle: { borderRadius: 8, borderColor: '#ffffff', borderWidth: 2 },
      label: { show: false },
      emphasis: {
        label: { show: true, fontSize: 14, fontWeight: 600, color: ink }
      },
      data: [
        { value: 35, name: '日志采集与监控', itemStyle: { color: accent } },
        { value: 25, name: '站内全文搜索', itemStyle: { color: accent2 } },
        { value: 15, name: '业务数据分析', itemStyle: { color: '#f59e0b' } },
        { value: 12, name: '安全威胁检测 (SIEM)', itemStyle: { color: '#10b981' } },
        { value: 13, name: '向量检索与 AI 应用', itemStyle: { color: '#f472b6' } }
      ]
    }]
  });
  window.addEventListener('resize', function () { chart3.resize(); });

  // --- Chart 4: 索引写入链路耗时构成 (示意) ---
  var chart4 = echarts.init(document.getElementById('chart-write'), null, { renderer: 'svg' });
  chart4.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true },
    grid: { left: 60, right: 30, top: 30, bottom: 40 },
    xAxis: {
      type: 'category',
      data: ['单条写入', '批量写入 (bulk)'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '写入吞吐 (万条/秒)',
      nameTextStyle: { color: muted },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted }
    },
    series: [{
      type: 'bar',
      barWidth: 48,
      data: [
        { value: 1.2, itemStyle: { color: accent2, borderRadius: [6, 6, 0, 0] } },
        { value: 25, itemStyle: { color: accent, borderRadius: [6, 6, 0, 0] } }
      ],
      label: {
        show: true,
        position: 'top',
        color: ink,
        formatter: '{c} 万/秒'
      }
    }]
  });
  window.addEventListener('resize', function () { chart4.resize(); });
})();
